//
//  AppDelegate.h
//  voiceitapidemo
//
//  Created by Neo on 13-9-27.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
