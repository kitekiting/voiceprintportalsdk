//
//  ViewController.h
//  voiceitapidemo
//
//  Created by Neo on 13-9-27.
//
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ViewController : UIViewController<UITextFieldDelegate,UIAlertViewDelegate,UIScrollViewDelegate,AVAudioPlayerDelegate> {
@private
    bool isEnrollment;
    NSURL *recordedFile;
    AVAudioRecorder *recorder;
    AVAudioPlayer *player;
    NSURL * beepFile;
    NSURL * beforeEnrollFile;
    NSTimer *voiceTimer;
}
@property (weak, nonatomic) IBOutlet UIButton *createUserBtn;
@property (weak, nonatomic) IBOutlet UIButton *updateUserBtn;
@property (weak, nonatomic) IBOutlet UIButton *retrieveUserBtn;
@property (weak, nonatomic) IBOutlet UIButton *deleteUserBtn;
@property (weak, nonatomic) IBOutlet UIButton *enrollmentNewBtn;
@property (weak, nonatomic) IBOutlet UIButton *enrollmentShowBtn;
@property (weak, nonatomic) IBOutlet UIButton *enrollmentDeleteBtn;
@property (weak, nonatomic) IBOutlet UIButton *authenticateBtn;
@property (weak, nonatomic) IBOutlet UITextField *emailText;
@property (weak, nonatomic) IBOutlet UITextField *passwordText;
@property (weak, nonatomic) IBOutlet UITextField *developerIdText;
@property (weak, nonatomic) IBOutlet UITextField *firstnameText;
@property (weak, nonatomic) IBOutlet UITextField *lastnameText;
@property (weak, nonatomic) IBOutlet UITextField *phone1Text;
@property (weak, nonatomic) IBOutlet UITextField *phone2Text;
@property (weak, nonatomic) IBOutlet UITextField *phone3Text;
@property (weak, nonatomic) IBOutlet UITextField *enrollmentIdText;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UISlider *accuracySlider;
@property (weak, nonatomic) IBOutlet UISlider *accuracyPassesSlider;
@property (weak, nonatomic) IBOutlet UISlider *accuracyPassIncrementSlider;
@property (weak, nonatomic) IBOutlet UISlider *confidenceSlider;
@property (weak, nonatomic) IBOutlet UILabel *accuracyLabel;
@property (weak, nonatomic) IBOutlet UILabel *accuracyPassesLabel;
@property (weak, nonatomic) IBOutlet UILabel *accuracyPassIncrementLabel;
@property (weak, nonatomic) IBOutlet UILabel *confidenceLabel;
@property (weak, nonatomic) IBOutlet UILabel *userAPIsLabel;
@property (weak, nonatomic) IBOutlet UILabel *enrollmentAPIsLabel;
@property (weak, nonatomic) IBOutlet UILabel *authenticationAPILabel;
@property (weak, nonatomic) IBOutlet UILabel *accuracyTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *accuracyPassesTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *accuracyPassIncrementTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *confidenceTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *accuracy60Label;
@property (weak, nonatomic) IBOutlet UILabel *accuracy0Label;
@property (weak, nonatomic) IBOutlet UILabel *accuracyPasses1Label;
@property (weak, nonatomic) IBOutlet UILabel *accuracyPasses10Label;
@property (weak, nonatomic) IBOutlet UILabel *accuracyPassIncrement1Label;
@property (weak, nonatomic) IBOutlet UILabel *accuracyPassIncrement60Label;
@property (weak, nonatomic) IBOutlet UILabel *confidence85Label;
@property (weak, nonatomic) IBOutlet UILabel *confidence100Label;
@property (weak, nonatomic) IBOutlet UISwitch *voiceOversSwitch;
@property (weak, nonatomic) IBOutlet UILabel *voiceOversLabel;
@property (weak, nonatomic) IBOutlet UISwitch *voicePlaybackSwitch;
@property (weak, nonatomic) IBOutlet UILabel *voicePlaybackLabel;

- (IBAction)createUserAction:(id)sender;
- (IBAction)retrieveUserAction:(id)sender;
- (IBAction)updateUserAction:(id)sender;
- (IBAction)deleteUserAction:(id)sender;
- (IBAction)enrollmentNewAction:(id)sender;
- (IBAction)enrollmentShowAction:(id)sender;
- (IBAction)enrollmentDeleteAction:(id)sender;
- (IBAction)authenticateAction:(id)sender;
- (IBAction)accuracySliderValueChange:(id)sender;
- (IBAction)accuracyPassesSliderValueChange:(id)sender;
- (IBAction)accuracyPassIncrementSliderValueChange:(id)sender;
- (IBAction)confidenceSliderValueChange:(id)sender;
- (BOOL)textFieldShouldReturn:(UITextField *)textField;
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
@end
