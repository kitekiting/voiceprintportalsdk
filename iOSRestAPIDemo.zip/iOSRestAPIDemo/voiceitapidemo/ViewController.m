//
//  ViewController.m
//  voiceitapidemo
//
//  Created by Neo on 13-9-27.
//
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "NetHelper.h"
#import <CommonCrypto/CommonDigest.h>
@interface ViewController ()

@end

@implementation UIScrollView (UITouchEvent)

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [[self nextResponder] touchesBegan:touches withEvent:event];
    [super touchesBegan:touches withEvent:event];
}

@end
@implementation ViewController

//@synthesize scrollView;

-(NSString*) sha256:(NSString*)input
{
	const char *cstr = [input cStringUsingEncoding:NSUTF8StringEncoding];
	NSData *data = [NSData dataWithBytes:cstr length:input.length];
	
	uint8_t digest[CC_SHA256_DIGEST_LENGTH];
	
	CC_SHA256(data.bytes, data.length, digest);
	
	NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH * 2];
	
	for(int i = 0; i < CC_SHA256_DIGEST_LENGTH; i++)
		[output appendFormat:@"%02x", digest[i]];
	
	return output;
	
}
-(BOOL)isPureInt:(NSString *) string {
    NSScanner * scan = [NSScanner scannerWithString:string];
    int val;
    return [scan scanInt:&val] && [scan isAtEnd];
}
-(void)clearTextFields {
    _emailText.text=nil;
    _passwordText.text=nil;
    _developerIdText.text=nil;
    _firstnameText.text=nil;
    _lastnameText.text=nil;
    _phone1Text.text=nil;
    _phone2Text.text=nil;
    _phone3Text.text=nil;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSString * resPath = [[NSBundle mainBundle] resourcePath];
    NSString * beepFilePath = [resPath stringByAppendingString:@"/beep.wav"];
    NSString * beforeEnrollFilePath = [resPath stringByAppendingString:@"/beforeenrollment.wav"];
    
    beepFile = [NSURL fileURLWithPath:beepFilePath];
    beforeEnrollFile = [NSURL fileURLWithPath:beforeEnrollFilePath];
    
   _scrollView.frame = CGRectMake(0, 42, self.view.bounds.size.width, self.view.bounds.size.height);

    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone){
        if (self.view.bounds.size.height>480) {
            _scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, self.view.bounds.size.height+260);
        } else {
            _scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, self.view.bounds.size.height+360);
        }
    } else {
        _scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, self.view.bounds.size.height);
    }

    
//    _emailText.autocorrectionType = UITextAutocorrectionTypeNo;
//    _emailText.autocapitalizationType = UITextAutocapitalizationTypeNone;
    _emailText.delegate = self;
    _emailText.returnKeyType = UIReturnKeyNext;
    
    _passwordText.delegate = self;
    _passwordText.returnKeyType = UIReturnKeyNext;
//    _passwordText.autocorrectionType = UITextAutocorrectionTypeNo;
//    _passwordText.autocapitalizationType = UITextAutocapitalizationTypeNone;
    
    _developerIdText.delegate = self;
    _developerIdText.returnKeyType = UIReturnKeyDone;
    
    _firstnameText.delegate = self;
    _firstnameText.returnKeyType = UIReturnKeyNext;
    _lastnameText.delegate = self;
    _lastnameText.returnKeyType = UIReturnKeyNext;
    _phone1Text.delegate = self;
    _phone1Text.returnKeyType = UIReturnKeyNext;
    _phone2Text.delegate = self;
    _phone2Text.returnKeyType = UIReturnKeyNext;
    _phone3Text.delegate = self;
    _phone3Text.returnKeyType = UIReturnKeyDone;
    _enrollmentIdText.delegate = self;
    _enrollmentIdText.returnKeyType = UIReturnKeyDone;
    
    _accuracySlider.minimumValue = -5.0;
    _accuracySlider.maximumValue = 0.0;
    _accuracySlider.value = 0.0;
    
    _accuracyPassesSlider.maximumValue = 10;
    _accuracyPassesSlider.minimumValue = 1;
    _accuracyPassesSlider.value = 5;
    
    _accuracyPassIncrementSlider.maximumValue = 5;
    _accuracyPassIncrementSlider.minimumValue = 1;
    _accuracyPassIncrementSlider.value = 2;
    
    _confidenceSlider.minimumValue = 85.0;
    _confidenceSlider.maximumValue = 100.0;
    _confidenceSlider.value = 85.0;
    
    if([[[UIDevice currentDevice] systemVersion] floatValue]<7.0) {
        for (UIView * currentView in [self.scrollView subviews]) {
            if( [currentView isKindOfClass:[UIButton class]]) {
                UIButton * currentBtn = (UIButton *)currentView;
                currentBtn.backgroundColor = [UIColor clearColor];
            }
        }
    }
    
    
//    NSLog(@"macOutString:%@", [self digest:@"1357924680"]);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)createUserAction:(id)sender {
    NSString * message = nil;
    if (_emailText.text == nil || _emailText.text.length == 0) {
        message = @"Email address is required!";
    } else if (_passwordText.text == nil || _passwordText.text.length == 0) {
        message = @"Password is required!";
    } else if (_developerIdText.text == nil || _developerIdText.text.length == 0) {
        message = @"Developer ID is required!";
    } else if (![self isPureInt:_developerIdText.text ] || _developerIdText.text.length > 6) {
        message = @"Developer ID must be a 6 digitals number!";
    } else if (_firstnameText.text == nil || _firstnameText.text.length == 0) {
        message = @"FirstName is required!";
    } else if (_lastnameText.text == nil || _lastnameText.text.length == 0) {
        message = @"LastName is required!";
    } else {
        NetHelper * netHelper = [[NetHelper alloc]init];
        NSMutableDictionary * paramDic= [[NSMutableDictionary alloc] init];
        [paramDic setObject:_emailText.text forKey:@"VsitEmail"];
        [paramDic setObject:[self sha256:_passwordText.text] forKey:@"VsitPassword"];
        [paramDic setObject:_developerIdText.text forKey:@"VsitDeveloperId"];
        [paramDic setObject:_firstnameText.text forKey:@"VsitFirstName"];
        [paramDic setObject:_lastnameText.text forKey:@"VsitLastName"];
        if (_phone1Text.text !=nil && _phone1Text.text.length>0) {
            [paramDic setObject:_phone1Text.text forKey:@"VsitPhone1"];
        }
        if (_phone2Text.text !=nil && _phone2Text.text.length>0) {
            [paramDic setObject:_phone2Text.text forKey:@"VsitPhone2"];
        }
        if (_phone3Text.text !=nil && _phone3Text.text.length>0) {
            [paramDic setObject:_phone3Text.text forKey:@"VsitPhone3"];
        }
        
        NSDictionary * dic = [netHelper postRequestAndResponse:@"users" headerParams:paramDic];
        if (dic !=nil) {
            message = [dic objectForKey:@"Result"];
        } else {
            message = @"Internet Connection Needed or Failed!";
        }
    }
    
    if (message !=nil){
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [alertView show];
        });
    }
    
}
- (IBAction)retrieveUserAction:(id)sender {
    NSString * message = nil;
    if (_emailText.text == nil || _emailText.text.length == 0) {
        message = @"Email address is required!";
    } else if (_passwordText.text == nil || _passwordText.text.length == 0) {
        message = @"Password is required!";
    } else if (_developerIdText.text == nil || _developerIdText.text.length == 0) {
        message = @"Developer ID is required!";
    } else if (![self isPureInt:_developerIdText.text ] || _developerIdText.text.length > 6) {
        message = @"Developer ID must be a 6 digitals number!";
    } else {
        NetHelper * netHelper = [[NetHelper alloc]init];
        NSMutableDictionary * paramDic= [[NSMutableDictionary alloc] init];
        [paramDic setObject:_emailText.text forKey:@"VsitEmail"];
        [paramDic setObject:[self sha256:_passwordText.text] forKey:@"VsitPassword"];
        [paramDic setObject:_developerIdText.text forKey:@"VsitDeveloperId"];
        
        NSDictionary * dic = [netHelper getRequestAndResponseDic:@"users" headerParams:paramDic];
        if (dic !=nil) {
            if ( [dic objectForKey:@"Result"] == nil) {
               _firstnameText.text = [dic objectForKey:@"FirstName"];
               _lastnameText.text = [dic objectForKey:@"LastName"];
               _phone1Text.text = [dic objectForKey:@"Phone1"];
               _phone2Text.text = [dic objectForKey:@"Phone2"];
               _phone3Text.text = [dic objectForKey:@"Phone3"];
            }
            else {
                message = [dic objectForKey:@"Result"];            }
        } else {
            message = @"Internet Connection Needed or Failed!";
        }
    }
    
    if (message !=nil){
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [alertView show];
        });
    }
    
}
- (IBAction)updateUserAction:(id)sender {
    NSString * message = nil;
    if (_emailText.text == nil || _emailText.text.length == 0) {
        message = @"Email address is required!";
    } else if (_passwordText.text == nil || _passwordText.text.length == 0) {
        message = @"Password is required!";
    } else if (_developerIdText.text == nil || _developerIdText.text.length == 0) {
        message = @"Developer ID is required!";
    } else if (![self isPureInt:_developerIdText.text ] || _developerIdText.text.length > 6) {
        message = @"Developer ID must be a 6 digitals number!";
    } else if (_firstnameText.text == nil || _firstnameText.text.length == 0) {
        message = @"FirstName is required!";
    } else if (_lastnameText.text == nil || _lastnameText.text.length == 0) {
        message = @"LastName is required!";
    } else {
        NetHelper * netHelper = [[NetHelper alloc]init];
        NSMutableDictionary * paramDic= [[NSMutableDictionary alloc] init];
        [paramDic setObject:_emailText.text forKey:@"VsitEmail"];
        [paramDic setObject:[self sha256:_passwordText.text] forKey:@"VsitPassword"];
        [paramDic setObject:_developerIdText.text forKey:@"VsitDeveloperId"];
        [paramDic setObject:_firstnameText.text forKey:@"VsitFirstName"];
        [paramDic setObject:_lastnameText.text forKey:@"VsitLastName"];
        if (_phone1Text.text !=nil && _phone1Text.text.length>0) {
            [paramDic setObject:_phone1Text.text forKey:@"VsitPhone1"];
        }
        if (_phone2Text.text !=nil && _phone2Text.text.length>0) {
            [paramDic setObject:_phone2Text.text forKey:@"VsitPhone2"];
        }
        if (_phone3Text.text !=nil && _phone3Text.text.length>0) {
            [paramDic setObject:_phone3Text.text forKey:@"VsitPhone3"];
        }
        
        NSDictionary * dic =[netHelper putRequestAndResponse:@"users" headerParams:paramDic];
        if (dic !=nil) {
            message = [dic objectForKey:@"Result"];
        } else {
            message = @"Internet Connection Needed or Failed!";
        }
    }
    
    if (message !=nil){
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [alertView show];
        });
    }
    
}
- (IBAction)deleteUserAction:(id)sender {
    NSString * message = nil;
    if (_emailText.text == nil || _emailText.text.length == 0) {
        message = @"Email address is required!";
    } else if (_passwordText.text == nil || _passwordText.text.length == 0) {
        message = @"Password is required!";
    } else if (_developerIdText.text == nil || _developerIdText.text.length == 0) {
        message = @"Developer ID is required!";
    } else if (![self isPureInt:_developerIdText.text ] || _developerIdText.text.length > 6) {
        message = @"Developer ID must be a 6 digitals number!";
    } else {
        NetHelper * netHelper = [[NetHelper alloc]init];
        NSMutableDictionary * paramDic= [[NSMutableDictionary alloc] init];
        [paramDic setObject:_emailText.text forKey:@"VsitEmail"];
        [paramDic setObject:[self sha256:_passwordText.text] forKey:@"VsitPassword"];
        [paramDic setObject:_developerIdText.text forKey:@"VsitDeveloperId"];
        
        NSDictionary * dic = [netHelper deleteRequestAndResponse:@"users" headerParams:paramDic];
        if (dic !=nil) {
            message = [dic objectForKey:@"Result"];
            if ([[dic objectForKey:@"Result"]  isEqual: @"Success"]) {
               [self clearTextFields];
               [_emailText becomeFirstResponder];
            }
        } else {
            message = @"Internet Connection Needed or Failed!";
        }
    }
    
    if (message !=nil){
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [alertView show];
        });
    }
    
}
-(void) playBeep {
    NSError *playerError;
    player = [[AVAudioPlayer alloc] initWithContentsOfURL:beepFile error:&playerError];
    
    if (player == nil)
    {
        NSLog(@"ERror creating player: %@", [playerError description]);
    }
    
    OSStatus result;
    UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;
    result = AudioSessionSetProperty (kAudioSessionProperty_OverrideAudioRoute, sizeof (audioRouteOverride), &audioRouteOverride);
    
    [player play];
}
-(void) playBeepTimer:(NSTimer *) timer {
    [self playBeep];
    voiceTimer=[NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(startRecordAndShowAlert:) userInfo:[timer userInfo] repeats:NO];
}
-(void) playBeforeEnroll {
    NSError *playerError;
    
    player = [[AVAudioPlayer alloc] initWithContentsOfURL:beforeEnrollFile error:&playerError];
    
    if (player == nil)
    {
        NSLog(@"Error creating player: %@", [playerError description]);
    }
    player.delegate = self;
    
    OSStatus result;
    UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;
    result = AudioSessionSetProperty (kAudioSessionProperty_OverrideAudioRoute, sizeof (audioRouteOverride), &audioRouteOverride);
    
    [player play];
}
- (IBAction)enrollmentNewAction:(id)sender {
    NSString * message = nil;
    if (_emailText.text == nil || _emailText.text.length == 0) {
        message = @"Email address is required!";
    } else if (_passwordText.text == nil || _passwordText.text.length == 0) {
        message = @"Password is required!";
    } else if (_developerIdText.text == nil || _developerIdText.text.length == 0) {
        message = @"Developer ID is required!";
    } else if (![self isPureInt:_developerIdText.text ] || _developerIdText.text.length > 6) {
        message = @"Developer ID must be a 6 digitals number!";
    } else {
        [self disableAllButtons];
        if (_voiceOversSwitch.on) {
            [self playBeforeEnroll];
            voiceTimer=[NSTimer scheduledTimerWithTimeInterval:3.2 target:self selector:@selector(playBeepTimer:) userInfo:[NSNumber numberWithBool:YES] repeats:NO];
        } else {
            [self playBeep];
            voiceTimer=[NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(startRecordAndShowAlert:) userInfo:[NSNumber numberWithBool:YES] repeats:NO];
        }
    }
    
    if (message !=nil){
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [alertView show];
        });
    }
}

- (IBAction)enrollmentShowAction:(id)sender {
    NSString * message = nil;
    if (_emailText.text == nil || _emailText.text.length == 0) {
        message = @"Email address is required!";
    } else if (_passwordText.text == nil || _passwordText.text.length == 0) {
        message = @"Password is required!";
    } else if (_developerIdText.text == nil || _developerIdText.text.length == 0) {
        message = @"Developer ID is required!";
    } else if (![self isPureInt:_developerIdText.text ] || _developerIdText.text.length > 6) {
        message = @"Developer ID must be a 6 digitals number!";
    } else {
        NetHelper * netHelper = [[NetHelper alloc]init];
        NSMutableDictionary * paramDic= [[NSMutableDictionary alloc] init];
        [paramDic setObject:_emailText.text forKey:@"VsitEmail"];
        [paramDic setObject:[self sha256:_passwordText.text] forKey:@"VsitPassword"];
        [paramDic setObject:_developerIdText.text forKey:@"VsitDeveloperId"];
        
        NSDictionary * result = [netHelper getRequestAndResponseString:@"enrollments" headerParams:paramDic];
        if (result !=nil) {
            message = [result objectForKey:@"Result"];
        } else {
            message = @"Internet Connection Needed or Failed!";
        }
    }
    
    if (message !=nil){
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [alertView show];
        });
    }
}

- (IBAction)enrollmentDeleteAction:(id)sender {
    NSString * message = nil;
    if (_emailText.text == nil || _emailText.text.length == 0) {
        message = @"Email address is required!";
    } else if (_passwordText.text == nil || _passwordText.text.length == 0) {
        message = @"Password is required!";
    } else if (_developerIdText.text == nil || _developerIdText.text.length == 0) {
        message = @"Developer ID is required!";
    } else if (![self isPureInt:_developerIdText.text ] || _developerIdText.text.length > 6) {
        message = @"Developer ID must be a 6 digitals number!";
    } else if (_enrollmentIdText.text == nil || _enrollmentIdText.text.length == 0) {
        message = @"Enrollment ID is required!";
    } else if (![self isPureInt:_enrollmentIdText.text ]) {
        message = @"Enrollment ID is must be a number!";
    } else {
        NetHelper * netHelper = [[NetHelper alloc]init];
        NSMutableDictionary * paramDic= [[NSMutableDictionary alloc] init];
        [paramDic setObject:_emailText.text forKey:@"VsitEmail"];
        [paramDic setObject:[self sha256:_passwordText.text] forKey:@"VsitPassword"];
        [paramDic setObject:_developerIdText.text forKey:@"VsitDeveloperId"];
        
        NSDictionary * dic = [netHelper deleteRequestAndResponse:[NSString stringWithFormat:@"enrollments/%@",_enrollmentIdText.text] headerParams:paramDic];
        if (dic !=nil) {
            message = [dic objectForKey:@"Result"];
            _enrollmentIdText.text=nil;
            [_enrollmentIdText becomeFirstResponder];
        } else {
            message = @"Internet Connection Needed or Failed!";
        }
    }
    
    if (message !=nil){
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [alertView show];
        });
    }
}

- (void)startRecordAndShowAlert:(NSTimer *) timer {
    UIAlertView * alertView = nil;
    if ([[timer userInfo] isEqualToNumber:[NSNumber numberWithBool:YES]]) {
        alertView = [[UIAlertView alloc] initWithTitle:@"New Enrollment" message:@"Recording..." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:nil, nil];
    } else {
        alertView = [[UIAlertView alloc] initWithTitle:@"Authenticate" message:@"Recording..." delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:nil, nil];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [alertView show];
    });
    
    recordedFile = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingString:@"RecordedFile.wav"]];
    AVAudioSession *session = [AVAudioSession sharedInstance];
    
    NSError *sessionError;
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:&sessionError];
    
    if(session == nil)
        NSLog(@"Error creating session: %@", [sessionError description]);
    else
        [session setActive:YES error:nil];
    NSDictionary * recordSettings = [[NSDictionary alloc] initWithObjectsAndKeys:
                                     [NSNumber numberWithFloat:11025.0], AVSampleRateKey,
                                     [NSNumber numberWithInt:kAudioFormatLinearPCM], AVFormatIDKey,
                                     [NSNumber numberWithInt:16], AVLinearPCMBitDepthKey,
                                     [NSNumber numberWithInt:2], AVNumberOfChannelsKey,
                                     [NSNumber numberWithBool:NO],AVLinearPCMIsBigEndianKey,
                                     [NSNumber numberWithBool:NO], AVLinearPCMIsFloatKey,
                                     nil];
    recorder = [[AVAudioRecorder alloc] initWithURL:recordedFile settings:recordSettings error:nil];
    [recorder prepareToRecord];
    [recorder record];
    if ([[timer userInfo] isEqualToNumber:[NSNumber numberWithBool:YES]])
        isEnrollment = YES;
    else
        isEnrollment = NO;
    
    [self performSelector:@selector(dismissAlertView:) withObject:alertView afterDelay:5];
}

- (IBAction)authenticateAction:(id)sender {
    NSString * message = nil;
    if (_emailText.text == nil || _emailText.text.length == 0) {
        message = @"Email address is required!";
    } else if (_passwordText.text == nil || _passwordText.text.length == 0) {
        message = @"Password is required!";
    } else if (_developerIdText.text == nil || _developerIdText.text.length == 0) {
        message = @"Developer ID is required!";
    } else if (![self isPureInt:_developerIdText.text ] || _developerIdText.text.length > 6) {
        message = @"Developer ID must be a 6 digitals number!";
    } else {
        [self disableAllButtons];
        if (_voiceOversSwitch.on) {
            [self playBeforeEnroll];
            voiceTimer=[NSTimer scheduledTimerWithTimeInterval:3.2 target:self selector:@selector(playBeepTimer:) userInfo:[NSNumber numberWithBool:NO] repeats:NO];
        } else {
            [self playBeep];
            voiceTimer=[NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(startRecordAndShowAlert:) userInfo:[NSNumber numberWithBool:NO] repeats:NO];
        }
    }
    
    if (message !=nil){
        UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:nil message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        dispatch_async(dispatch_get_main_queue(), ^{
            [alertView show];
        });
    }
}

- (IBAction)accuracySliderValueChange:(id)sender {
    UISlider * control = (UISlider *)sender;
    if (control == _accuracySlider) {
        _accuracyLabel.text = [NSString stringWithFormat:@"%d",(int) -_accuracySlider.value];
    }
}

- (IBAction)accuracyPassesSliderValueChange:(id)sender {
    UISlider * control = (UISlider *)sender;
    if (control == _accuracyPassesSlider) {
        _accuracyPassesLabel.text = [NSString stringWithFormat:@"%d",(int) _accuracyPassesSlider.value];
    }
}

- (IBAction)accuracyPassIncrementSliderValueChange:(id)sender {
    UISlider * control = (UISlider *)sender;
    if (control == _accuracyPassIncrementSlider) {
        _accuracyPassIncrementLabel.text = [NSString stringWithFormat:@"%d",(int) _accuracyPassIncrementSlider.value];
    }
}

- (IBAction)confidenceSliderValueChange:(id)sender {
    UISlider * control = (UISlider *)sender;
    if (control == _confidenceSlider) {
        _confidenceLabel.text = [NSString stringWithFormat:@"%d",(int) _confidenceSlider.value];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (textField == _emailText) {
        [_emailText resignFirstResponder];
        [_passwordText becomeFirstResponder];
    } else if (textField == _passwordText) {
        [_passwordText resignFirstResponder];
        [_developerIdText becomeFirstResponder];
    } else if (textField == _developerIdText) {
        [_developerIdText resignFirstResponder];
    } else if (textField == _firstnameText) {
        [_firstnameText resignFirstResponder];
        [_lastnameText becomeFirstResponder];
    } else if (textField == _lastnameText) {
        [_lastnameText resignFirstResponder];
        [_phone1Text becomeFirstResponder];
    } else if (textField == _phone1Text) {
        [_phone1Text resignFirstResponder];
        [_phone2Text becomeFirstResponder];
    } else if (textField == _phone2Text) {
        [_phone2Text resignFirstResponder];
        [_phone3Text becomeFirstResponder];
    } else if (textField == _phone3Text) {
        [_phone3Text resignFirstResponder];
    } else if (textField == _enrollmentIdText) {
        [_enrollmentIdText resignFirstResponder];
    }
    return YES;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [_emailText resignFirstResponder];
    [_passwordText resignFirstResponder];
    [_developerIdText resignFirstResponder];
    [_firstnameText resignFirstResponder];
    [_lastnameText resignFirstResponder];
    [_phone1Text resignFirstResponder];
    [_phone2Text resignFirstResponder];
    [_phone3Text resignFirstResponder];
    [_enrollmentIdText resignFirstResponder];
    
}
/*-(void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    if(UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone){
        if (self.interfaceOrientation == UIInterfaceOrientationPortrait) {
            [self drawPortraitForPhone];
        } else {
            if([[UIScreen mainScreen] bounds].size.height == 568) {
                [self drawLandscapeForPhoneSize4];
            } else {
                [self drawLandscapeForPhoneSize3];
            }
        }
    } else {
        _scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, self.view.bounds.size.height);
    }
} */
/*-(void)drawPortraitForPhone {
    _scrollView.frame = CGRectMake(0, 44, self.view.bounds.size.width, self.view.bounds.size.height);
    if (self.view.bounds.size.height>480) {
        _scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, self.view.bounds.size.height+160);
    } else {
        _scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, self.view.bounds.size.height+260);
    }
    _emailText.frame = CGRectMake(20, 20, 280, 30);
    _passwordText.frame = CGRectMake(20, 56, 280, 30);
    _developerIdText.frame = CGRectMake(20, 92, 280, 30);
    _voiceOversLabel.frame = CGRectMake(20, 134, 81, 21);
    _voicePlaybackLabel.frame = CGRectMake(20, 168, 98, 21);
    if ([[[UIDevice currentDevice] systemVersion] floatValue]>=7.0) {
        _voiceOversSwitch.frame = CGRectMake(251, 129, 51, 31);
        _voicePlaybackSwitch.frame = CGRectMake(251, 163, 51, 31);
    } else {
        _voiceOversSwitch.frame = CGRectMake(221, 129, 51, 31);
        _voicePlaybackSwitch.frame = CGRectMake(221, 163, 51, 31);
    }
    _userAPIsLabel.frame = CGRectMake(20, 194, 81, 21);
    _createUserBtn.frame = CGRectMake(26, 223, 130, 25);
    _retrieveUserBtn.frame = CGRectMake(26, 262, 130, 25);
    _updateUserBtn.frame = CGRectMake(26, 300, 130, 25);
    _deleteUserBtn.frame = CGRectMake(26, 338, 130, 25);
    _firstnameText.frame = CGRectMake(170, 217, 130, 30);
    _lastnameText.frame = CGRectMake(170, 255, 130, 30);
    _phone1Text.frame = CGRectMake(170, 293, 130, 30);
    _phone2Text.frame = CGRectMake(170, 331, 130, 30);
    _phone3Text.frame = CGRectMake(170, 369, 130, 30);
    _enrollmentAPIsLabel.frame = CGRectMake(20, 399, 217, 21);
    _enrollmentNewBtn.frame = CGRectMake(26, 428, 130, 25);
    _enrollmentShowBtn.frame = CGRectMake(170, 428, 130, 25);
    _enrollmentIdText.frame = CGRectMake(26, 459, 130, 30);
    _enrollmentDeleteBtn.frame = CGRectMake(170, 461, 130, 25);
    _authenticationAPILabel.frame = CGRectMake(20, 493, 147, 21);
    _authenticateBtn.frame = CGRectMake(170, 509, 130, 25);
    _accuracyTitleLabel.frame = CGRectMake(20, 542, 225, 21);
    _accuracyLabel.frame = CGRectMake(253, 542, 20, 21);
    _accuracy60Label.frame = CGRectMake(25, 566, 20, 21);
    _accuracy0Label.frame = CGRectMake(281, 566, 10, 21);
    _accuracySlider.frame = CGRectMake(46, 560, 229, 34);
    _confidenceTitleLabel.frame = CGRectMake(20, 600, 161, 21);
    _confidenceLabel.frame = CGRectMake(189, 600, 29, 21);
    _confidence85Label.frame = CGRectMake(25, 631, 20, 21);
    _confidence100Label.frame = CGRectMake(277, 631, 29, 21);
    _confidenceSlider.frame = CGRectMake(46, 625, 229, 34);
    
} */
/*-(void)drawLandscapeForPhoneSize3 {
    _scrollView.frame = CGRectMake(0, 44, self.view.bounds.size.width, self.view.bounds.size.height);
    _scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, 485+44);
    _emailText.frame = CGRectMake(20, 20, 220, 30);
    _passwordText.frame = CGRectMake(248, 20, 220, 30);
    _developerIdText.frame = CGRectMake(20, 56, 220, 30);
    _voiceOversLabel.frame = CGRectMake(20, 95, 81, 21);
    _voicePlaybackLabel.frame = CGRectMake(248, 95, 98, 21);
    if ([[[UIDevice currentDevice] systemVersion] floatValue]>=7.0) {
        _voiceOversSwitch.frame = CGRectMake(188, 90, 51, 31);
        _voicePlaybackSwitch.frame = CGRectMake(416, 90, 51, 31);
    } else {
        _voiceOversSwitch.frame = CGRectMake(158, 90, 51, 31);
        _voicePlaybackSwitch.frame = CGRectMake(386, 90, 51, 31);
    }
    _userAPIsLabel.frame = CGRectMake(20, 123, 81, 21);
    _createUserBtn.frame = CGRectMake(20, 152, 130, 25);
    _retrieveUserBtn.frame = CGRectMake(20, 185, 130, 25);
    _updateUserBtn.frame = CGRectMake(20, 218, 130, 25);
    _deleteUserBtn.frame = CGRectMake(20, 251, 130, 25);
    _firstnameText.frame = CGRectMake(165, 152, 130, 30);
    _lastnameText.frame = CGRectMake(165, 190, 130, 30);
    _phone1Text.frame = CGRectMake(308, 152, 130, 30);
    _phone2Text.frame = CGRectMake(308, 190, 130, 30);
    _phone3Text.frame = CGRectMake(308, 228, 130, 30);
    _enrollmentAPIsLabel.frame = CGRectMake(20, 284, 217, 21);
    _enrollmentNewBtn.frame = CGRectMake(20, 318, 130, 25);
    _enrollmentShowBtn.frame = CGRectMake(165, 318, 130, 25);
    _enrollmentIdText.frame = CGRectMake(308, 284, 130, 30);
    _enrollmentDeleteBtn.frame = CGRectMake(308, 318, 130, 25);
    _authenticationAPILabel.frame = CGRectMake(20, 360, 147, 21);
    _authenticateBtn.frame = CGRectMake(175, 372, 130, 25);
    _accuracyTitleLabel.frame = CGRectMake(20, 405, 225, 21);
    _accuracyLabel.frame = CGRectMake(248, 405, 20, 21);
    _accuracy60Label.frame = CGRectMake(20, 440, 20, 21);
    _accuracy0Label.frame = CGRectMake(248, 440, 10, 21);
    _accuracySlider.frame = CGRectMake(46, 434, 196, 34);
    _confidenceTitleLabel.frame = CGRectMake(277, 405, 161, 21);
    _confidenceLabel.frame = CGRectMake(446, 405, 29, 21);
    _confidence85Label.frame = CGRectMake(268, 440, 20, 21);
    _confidence100Label.frame = CGRectMake(439, 440, 29, 21);
    _confidenceSlider.frame = CGRectMake(296, 434, 137, 34);
} */
/*-(void)drawLandscapeForPhoneSize4 {
    _scrollView.frame = CGRectMake(0, 44, self.view.bounds.size.width, self.view.bounds.size.height);
    _scrollView.contentSize = CGSizeMake(self.view.bounds.size.width, 485+44);
    _emailText.frame = CGRectMake(20, 20, 260, 30);
    _passwordText.frame = CGRectMake(288, 20, 260, 30);
    _developerIdText.frame = CGRectMake(20, 56, 260, 30);
    _voiceOversLabel.frame = CGRectMake(20, 95, 81, 21);
    _voicePlaybackLabel.frame = CGRectMake(288, 95, 98, 21);
    if ([[[UIDevice currentDevice] systemVersion] floatValue]>=7.0) {
        _voiceOversSwitch.frame = CGRectMake(228, 90, 51, 31);
        _voicePlaybackSwitch.frame = CGRectMake(496, 90, 51, 31);
    } else {
        _voiceOversSwitch.frame = CGRectMake(198, 90, 51, 31);
        _voicePlaybackSwitch.frame = CGRectMake(466, 90, 51, 31);
    }
    _userAPIsLabel.frame = CGRectMake(20, 123, 81, 21);
    _createUserBtn.frame = CGRectMake(20, 152, 130, 25);
    _retrieveUserBtn.frame = CGRectMake(20, 185, 130, 25);
    _updateUserBtn.frame = CGRectMake(20, 218, 130, 25);
    _deleteUserBtn.frame = CGRectMake(20, 251, 130, 25);
    _firstnameText.frame = CGRectMake(158, 152, 130, 30);
    _lastnameText.frame = CGRectMake(296, 152, 130, 30);
    _phone1Text.frame = CGRectMake(158, 190, 130, 30);
    _phone2Text.frame = CGRectMake(296, 190, 130, 30);
    _phone3Text.frame = CGRectMake(434, 190, 130, 30);
    _enrollmentAPIsLabel.frame = CGRectMake(20, 284, 217, 21);
    _enrollmentNewBtn.frame = CGRectMake(20, 318, 130, 25);
    _enrollmentShowBtn.frame = CGRectMake(158, 318, 130, 25);
    _enrollmentIdText.frame = CGRectMake(296, 316, 130, 30);
    _enrollmentDeleteBtn.frame = CGRectMake(434, 318, 130, 25);
    _authenticationAPILabel.frame = CGRectMake(20, 360, 147, 21);
    _authenticateBtn.frame = CGRectMake(175, 372, 130, 25);
    _accuracyTitleLabel.frame = CGRectMake(20, 405, 225, 21);
    _accuracyLabel.frame = CGRectMake(248, 405, 20, 21);
    _accuracy60Label.frame = CGRectMake(20, 440, 20, 21);
    _accuracy0Label.frame = CGRectMake(248, 440, 10, 21);
    _accuracySlider.frame = CGRectMake(46, 434, 196, 34);
    _confidenceTitleLabel.frame = CGRectMake(296, 405, 161, 21);
    _confidenceLabel.frame = CGRectMake(465, 405, 29, 21);
    _confidence85Label.frame = CGRectMake(288, 440, 20, 21);
    _confidence100Label.frame = CGRectMake(519, 440, 29, 21);
    _confidenceSlider.frame = CGRectMake(317, 434, 196, 34);
}*/
-(void)playbackRecord {
    NSError *playerError;
    
    player = [[AVAudioPlayer alloc] initWithContentsOfURL:recordedFile error:&playerError];
    
    if (player == nil)
    {
        NSLog(@"Error creating player: %@", [playerError description]);
    }
    player.delegate = self;
     
    OSStatus result;
    UInt32 audioRouteOverride = kAudioSessionOverrideAudioRoute_Speaker;
    result = AudioSessionSetProperty (kAudioSessionProperty_OverrideAudioRoute, sizeof (audioRouteOverride), &audioRouteOverride);
    
    [player play];
}
-(void)sendRecordToServer {
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        NSString * message = nil;
        
        NetHelper * netHelper = [[NetHelper alloc]init];
        NSDictionary * resultDic =nil;
        NSMutableDictionary * paramDic= [[NSMutableDictionary alloc] init];
        [paramDic setObject:_emailText.text forKey:@"VsitEmail"];
        [paramDic setObject:[self sha256:_passwordText.text] forKey:@"VsitPassword"];
        [paramDic setObject:_developerIdText.text forKey:@"VsitDeveloperId"];
        if (!isEnrollment) {
            [paramDic setObject:[NSString stringWithFormat:@"%d",(int)-_accuracySlider.value] forKey:@"VsitAccuracy"];
            [paramDic setObject:[NSString stringWithFormat:@"%d",(int)_confidenceSlider.value] forKey:@"VsitConfidence"];
            [paramDic setObject:[NSString stringWithFormat:@"%d",(int)_accuracyPassesSlider.value] forKey:@"VsitAccuracyPasses"];
            [paramDic setObject:[NSString stringWithFormat:@"%d",(int)_accuracyPassIncrementSlider.value] forKey:@"VsitAccuracyPassIncrement"];
            resultDic = [netHelper postWavRequestAndResponseDic:@"authentications" headerParams:paramDic wavData:[[NSData alloc] initWithContentsOfURL:recordedFile]];
        } else {
            resultDic = [netHelper postWavRequestAndResponseDic:@"enrollments" headerParams:paramDic wavData:[[NSData alloc] initWithContentsOfURL:recordedFile]];
        }
        
        if (resultDic !=nil) {
            message = [resultDic objectForKey:@"Result"];
        } else {
            message = @"Internet Connection Needed or Failed!";
        }
        if (message !=nil){
            UIAlertView *alertView =[[UIAlertView alloc]initWithTitle:@"Result" message:message delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            dispatch_async(dispatch_get_main_queue(), ^{
                [alertView show];
                [self enableAllButtons];
            });
        }
    });
    
}
-(void)dismissAlertView:(UIAlertView *)alertView {
    [alertView dismissWithClickedButtonIndex:0 animated:YES];
    [recorder stop];
    recorder = nil;
    if (_voicePlaybackSwitch.on) {
        [self playbackRecord];
        voiceTimer=[NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(sendRecordToServer) userInfo:nil repeats:NO];
    } else {
        [self sendRecordToServer];
    }
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == [alertView cancelButtonIndex]) {
        [NSObject cancelPreviousPerformRequestsWithTarget:self];
        [recorder stop];
        recorder = nil;
        NSFileManager *fileManager = [NSFileManager defaultManager];
        [fileManager removeItemAtURL:recordedFile error:nil];
        recordedFile = nil;
        [self enableAllButtons];
    }
}
-(void)disableAllButtons {
    for (UIView * currentView in [self.scrollView subviews]) {
        if( [currentView isKindOfClass:[UIButton class]]) {
            UIButton * currentBtn = (UIButton *)currentView;
            currentBtn.enabled = NO;
            [currentBtn.titleLabel setAlpha:0.5];
        }
    }
    
}
-(void)enableAllButtons {
    for (UIView * currentView in [self.scrollView subviews]) {
        if( [currentView isKindOfClass:[UIButton class]]) {
            UIButton * currentBtn = (UIButton *)currentView;
            currentBtn.enabled = YES;
            [currentBtn.titleLabel setAlpha:1];
        }
    }
    
}
@end

